"""Otomatisasi formulir biasa. Tidak melewati OTP, CAPTCHA, atau checkpoint."""
from __future__ import annotations

from urllib.parse import urlsplit

from playwright.async_api import (
    Browser, BrowserContext, Error as PlaywrightError, Page, Playwright,
    TimeoutError as PlaywrightTimeoutError, async_playwright,
)

from profiles import Profile

SIGNUP_URL = "https://www.facebook.com/r.php"


class FormError(Exception):
    """Pesan aman untuk pengguna; jangan teruskan traceback yang memuat data isian."""


def is_facebook_url(url: str) -> bool:
    parsed = urlsplit(url)
    host = (parsed.hostname or "").lower()
    return parsed.scheme == "https" and (host == "facebook.com" or host.endswith(".facebook.com"))


async def fill_signup_fields(page: Page, profile: Profile, contact: str) -> None:
    if not is_facebook_url(page.url):
        raise FormError("Browser tidak berada di domain Facebook; tidak ada data yang diisikan.")
    # Nama field dapat berubah. Jika tidak cocok, berhenti, bukan menebak atau mengulang.
    await page.locator('input[name="firstname"]').fill(profile.first_name)
    await page.locator('input[name="lastname"]').fill(profile.last_name)
    contact_input = page.locator('input[name="reg_email__"]')
    await contact_input.fill(contact)
    await contact_input.press("Tab")
    if "@" in contact:
        confirmation = page.locator('input[name="reg_email_confirmation__"]')
        try:
            await confirmation.wait_for(state="visible", timeout=1500)
            await confirmation.fill(contact)
        except PlaywrightTimeoutError:
            # Sebagian versi formulir tidak mempunyai kolom konfirmasi email.
            pass
    await page.locator('input[name="reg_passwd__"]').fill(profile.password)
    await page.locator('select[name="birthday_day"]').select_option(str(profile.birth_date.day))
    await page.locator('select[name="birthday_month"]').select_option(str(profile.birth_date.month))
    await page.locator('select[name="birthday_year"]').select_option(str(profile.birth_date.year))
    await page.locator(f'input[name="sex"][value="{profile.sex_value}"]').check()


class FacebookForm:
    def __init__(self, *, headless: bool = False) -> None:
        self.headless = headless
        self.playwright: Playwright | None = None
        self.browser: Browser | None = None
        self.context: BrowserContext | None = None
        self.page: Page | None = None
        self.state = "idle"
        self.submit_attempted = False

    @property
    def is_open(self) -> bool:
        return bool(self.page is not None and not self.page.is_closed())

    async def open_and_fill(self, profile: Profile, contact: str) -> None:
        if self.is_open:
            raise FormError("Masih ada sesi browser terbuka. Tutup sesi sebelumnya dahulu.")
        self.state = "opening"
        self.submit_attempted = False
        try:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=self.headless)
            self.context = await self.browser.new_context(locale="id-ID")
            self.page = await self.context.new_page()
            self.page.set_default_timeout(12000)
            await self.page.goto(SIGNUP_URL, wait_until="domcontentloaded", timeout=60000)
            # Jika ada dialog cookie, pilih penolakan cookie opsional, bukan menerima semua.
            for label in ("Decline optional cookies", "Tolak cookie opsional", "Only allow essential cookies"):
                button = self.page.get_by_role("button", name=label, exact=True)
                if await button.count() == 1 and await button.is_visible():
                    await button.click(timeout=3000)
                    break
            await fill_signup_fields(self.page, profile, contact)
            self.state = "filled"
        except (PlaywrightError, FormError):
            if not self.is_open:
                await self.close()
            self.state = "needs_manual"
            raise FormError(
                "Formulir belum berhasil diisi lengkap. Penyebabnya bisa berupa perubahan tampilan, "
                "dialog, checkpoint, koneksi, atau browser tanpa layar. "
                "Periksa browser di komputer; bot tidak mengirim ulang otomatis. "
                "Jika browser belum terbuka, periksa instalasi Chromium dan lingkungan desktop."
            ) from None

    async def submit_once(self) -> None:
        if not self.is_open or self.page is None:
            raise FormError("Tidak ada browser aktif. Kirim nomor/email untuk memulai.")
        if self.submit_attempted:
            raise FormError("Pengiriman sudah pernah dicoba pada sesi ini. Periksa browser; bot tidak mengulanginya.")
        if self.state != "filled":
            raise FormError("Formulir belum siap. Selesaikan langkah yang diperlukan langsung di browser.")
        if not is_facebook_url(self.page.url):
            raise FormError("Browser bukan di domain Facebook. Pengiriman dihentikan.")
        # Tandai SEBELUM klik: timeout dapat terjadi sesudah server menerima data.
        self.submit_attempted = True
        self.state = "submission_uncertain"
        try:
            await self.page.locator('button[name="websubmit"]').click(timeout=15000)
        except PlaywrightError:
            raise FormError(
                "Tidak bisa memastikan hasil klik Daftar. Periksa browser. "
                "Bot sengaja tidak mencoba ulang agar tidak menggandakan permintaan."
            ) from None
        self.state = "clicked_not_verified"

    async def close(self) -> None:
        for resource in (self.context, self.browser):
            if resource is not None:
                try:
                    await resource.close()
                except PlaywrightError:
                    pass
        if self.playwright is not None:
            try:
                await self.playwright.stop()
            except PlaywrightError:
                pass
        self.page = None
        self.context = None
        self.browser = None
        self.playwright = None
        self.state = "closed"
