"""Bot Telegram privat untuk menyiapkan satu sesi formulir Facebook.

Jalankan: python bot.py
Token dan ID pemilik dibaca dari .env. Browser berjalan di komputer ini,
bukan di perangkat pengguna Telegram. Tidak ada integrasi pembaca SMS.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv
from telegram import BotCommand, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from facebook_form import FacebookForm, FormError
from profiles import (
    Profile, fresh_profile, mask_contact, normalize_contact,
    parse_real_profile, save_credentials,
)

ROOT = Path(__file__).resolve().parent
LOGGER = logging.getLogger("facebook_form_bot")


@dataclass(frozen=True)
class Settings:
    token: str = field(repr=False)
    owner_id: int | None
    auto_submit: bool
    credentials_dir: Path


def load_settings() -> Settings:
    load_dotenv(ROOT / ".env")
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token or ":" not in token:
        raise ValueError("Isi TELEGRAM_BOT_TOKEN di .env dengan token dari @BotFather.")
    owner_text = os.getenv("OWNER_TELEGRAM_ID", "").strip()
    try:
        owner_id = int(owner_text) if owner_text else None
    except ValueError:
        raise ValueError("OWNER_TELEGRAM_ID harus berupa angka dari perintah /id.") from None
    if owner_id is not None and owner_id <= 0:
        raise ValueError("OWNER_TELEGRAM_ID harus berupa ID pengguna positif, bukan ID grup.")
    auto_text = os.getenv("AUTO_SUBMIT", "false").strip().lower()
    if auto_text not in {"true", "false", "1", "0"}:
        raise ValueError("AUTO_SUBMIT harus true atau false.")
    directory = Path(os.getenv("CREDENTIALS_DIR", "credentials").strip() or "credentials")
    if not directory.is_absolute():
        directory = ROOT / directory
    return Settings(token, owner_id, auto_text in {"true", "1"}, directory.resolve())


class BotController:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.form = FacebookForm(headless=False)
        self.template: Profile | None = None
        self.last_file: Path | None = None
        self.last_contact_mask: str | None = None

    async def allowed(self, update: Update) -> bool:
        if update.effective_message is None or update.effective_user is None or update.effective_chat is None:
            return False
        if update.effective_chat.type != "private":
            await update.effective_message.reply_text("Gunakan percakapan pribadi dengan bot, bukan grup.")
            return False
        if self.settings.owner_id is None:
            await update.effective_message.reply_text(
                f"Mode penyiapan. ID Telegram Anda: {update.effective_user.id}\n"
                "Isi OWNER_TELEGRAM_ID di file .env, lalu restart bot. "
                "Belum ada kontak yang diproses."
            )
            return False
        if update.effective_user.id != self.settings.owner_id:
            await update.effective_message.reply_text("Bot ini hanya dapat digunakan oleh pemiliknya.")
            return False
        return True

    async def show_id(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_message and update.effective_chat and update.effective_user:
            if update.effective_chat.type == "private":
                await update.effective_message.reply_text(f"ID Telegram Anda: {update.effective_user.id}")

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        mode = "otomatis, satu kali setelah pengisian" if self.settings.auto_submit else "menunggu /kirim atau klik manual"
        await update.effective_message.reply_text(
            "Kirim satu nomor dengan kode negara (+62…) ATAU satu email.\n"
            "Bot membuat profil acak, menyimpan password di komputer, lalu membuka dan mengisi formulir.\n\n"
            f"Mode pengiriman: {mode}.\n"
            "Data acak adalah data dummy. Untuk akun sungguhan gunakan identitas yang sesuai aturan Facebook, "
            "misalnya atur data Anda melalui /profil terlebih dahulu. Jangan gunakan tanggal palsu untuk melewati syarat usia.\n\n"
            "/profil — atur data sebenarnya\n"
            "/acak — kembali ke data dummy acak\n"
            "/status — lihat status sesi\n"
            "/kirim — klik Daftar satu kali\n"
            "/tutup — tutup browser\n"
            "/id — lihat ID Telegram Anda\n\n"
            "OTP, CAPTCHA, dan checkpoint diselesaikan langsung di browser komputer ini. "
            "Jangan kirim OTP ke bot. Akun belum tentu berhasil dibuat setelah klik Daftar."
        )

    async def set_profile(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        text = (update.effective_message.text or "").partition(" ")[2].strip()
        try:
            self.template = parse_real_profile(text)
        except ValueError as error:
            await update.effective_message.reply_text(str(error))
            return
        await update.effective_message.reply_text(
            "Profil untuk sesi berikutnya sudah diatur. Data ini hanya disimpan dalam memori selama bot berjalan. "
            "Pastikan tanggal lahir dan identitasnya benar serta memenuhi persyaratan di negara Anda. "
            "Kirim nomor/email untuk memulai, atau /acak untuk kembali ke data dummy."
        )

    async def use_random(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        self.template = None
        await update.effective_message.reply_text(
            "Sesi berikutnya menggunakan nama, tanggal lahir, dan pilihan gender sintetis. "
            "Profil acak tidak membuktikan identitas atau usia pengguna dan bukan untuk melewati persyaratan Facebook."
        )

    async def register(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        message = update.effective_message
        text = (message.text or "").strip()
        raw = " ".join(context.args or []) if text.startswith("/") else text
        try:
            contact = normalize_contact(raw)
        except ValueError as error:
            await message.reply_text(str(error))
            return
        if self.form.is_open:
            await message.reply_text(
                "Masih ada satu sesi terbuka. Periksa browser atau /status. "
                "Gunakan /tutup sebelum memulai sesi lain. Tidak ada permintaan baru yang dikirim."
            )
            return
        await self.form.close()
        self.form = FacebookForm(headless=False)
        profile = fresh_profile(self.template)
        try:
            self.last_file = save_credentials(profile, contact, self.settings.credentials_dir)
        except OSError:
            await message.reply_text("Kredensial tidak bisa disimpan dengan aman di komputer. Proses dihentikan sebelum membuka formulir.")
            return
        self.last_contact_mask = mask_contact(contact)
        source = "Profil acak / dummy" if profile.synthetic else "Profil yang Anda atur"
        await message.reply_text(
            f"{source}\n"
            f"Nama: {profile.full_name}\n"
            f"Tanggal lahir: {profile.birth_date:%d-%m-%Y}\n"
            f"Pilihan gender: {profile.gender}\n"
            f"Kontak: {self.last_contact_mask}\n\n"
            f"Password TIDAK dikirim ke Telegram. File lokal di komputer:\n{self.last_file}\n\n"
            "Membuka browser dan mencoba mengisi formulir. Ini belum berarti akun sudah dibuat."
        )
        try:
            await self.form.open_and_fill(profile, contact)
        except FormError as error:
            await message.reply_text(str(error))
            return
        if self.settings.auto_submit:
            await self._submit_and_report(update)
        else:
            await message.reply_text(
                "Formulir sudah diisi, BELUM dikirim. Tinjau data di browser. "
                "Gunakan data sebenarnya untuk akun sungguhan.\n\n"
                "Ketik /kirim untuk klik Daftar satu kali, atau klik sendiri di browser. "
                "Jika sudah klik manual, jangan gunakan /kirim lagi. "
                "Perubahan manual pada data/password tidak memperbarui file JSON lokal."
            )

    async def _submit_and_report(self, update: Update) -> None:
        try:
            await self.form.submit_once()
        except FormError as error:
            await update.effective_message.reply_text(str(error))
            return
        await update.effective_message.reply_text(
            "Tombol Daftar sudah diklik satu kali. Ini BELUM membuktikan bahwa Facebook menerima formulir "
            "atau bahwa akun sudah aktif.\n\n"
            "Periksa hasilnya di browser. Jika diminta OTP, CAPTCHA, atau verifikasi identitas, "
            "selesaikan langsung di sana. Bot tidak membaca SMS/email dan tidak melewati pemeriksaan. "
            "Setelah selesai, gunakan /tutup."
        )

    async def submit(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if await self.allowed(update):
            await self._submit_and_report(update)

    async def status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        labels = {
            "idle": "Belum ada sesi.",
            "opening": "Sedang membuka formulir.",
            "filled": "Formulir terisi; bot belum mengklik Daftar.",
            "needs_manual": "Perlu pemeriksaan manual di komputer.",
            "submission_uncertain": "Pengiriman pernah dicoba; hasilnya tidak diketahui.",
            "clicked_not_verified": "Klik Daftar dilakukan; hasil belum diverifikasi.",
            "closed": "Browser ditutup.",
        }
        status_text = labels.get(self.form.state, "Status tidak diketahui.")
        browser_text = "terbuka" if self.form.is_open else "tidak terbuka"
        await update.effective_message.reply_text(
            f"{status_text}\nBrowser: {browser_text}.\n"
            f"Kontak sesi terakhir: {self.last_contact_mask or 'belum ada'}.\n\n"
            "Status bot bukan bukti akun aktif. Perubahan yang Anda lakukan manual di browser tidak dipantau."
        )

    async def close(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.allowed(update):
            return
        await self.form.close()
        await update.effective_message.reply_text(
            "Browser ditutup. Ini TIDAK membatalkan pendaftaran yang sudah dikirim dan tidak menghapus akun. "
            "File kredensial lokal tetap ada; simpan password di tempat aman lalu hapus file jika tidak diperlukan."
        )

    async def shutdown(self, application: Application) -> None:
        await self.form.close()


async def set_commands(application: Application) -> None:
    await application.bot.set_my_commands([
        BotCommand("start", "Petunjuk penggunaan"),
        BotCommand("id", "Lihat ID Telegram Anda"),
        BotCommand("daftar", "Mulai dengan satu nomor atau email"),
        BotCommand("profil", "Atur nama dan tanggal lahir sebenarnya"),
        BotCommand("acak", "Gunakan profil sintetis untuk sesi berikutnya"),
        BotCommand("kirim", "Klik Daftar satu kali"),
        BotCommand("status", "Status sesi, bukan bukti akun aktif"),
        BotCommand("tutup", "Tutup browser tanpa menghapus akun"),
    ])


async def report_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Exception Playwright/HTTP dapat mengandung data isian atau token. Jangan log isinya.
    LOGGER.error("Operasi gagal; jenis error: %s", type(context.error).__name__)
    if isinstance(update, Update) and update.effective_message is not None:
        await update.effective_message.reply_text(
            "Terjadi kesalahan. Periksa browser di komputer. "
            "Bot tidak otomatis mengulangi pengiriman formulir."
        )


def build_application(settings: Settings) -> Application:
    controller = BotController(settings)
    app = (
        Application.builder()
        .token(settings.token)
        .concurrent_updates(False)
        .post_init(set_commands)
        .post_shutdown(controller.shutdown)
        .build()
    )
    app.add_handler(CommandHandler(["start", "help"], controller.start))
    app.add_handler(CommandHandler("id", controller.show_id))
    app.add_handler(CommandHandler("daftar", controller.register))
    app.add_handler(CommandHandler("profil", controller.set_profile))
    app.add_handler(CommandHandler("acak", controller.use_random))
    app.add_handler(CommandHandler("kirim", controller.submit))
    app.add_handler(CommandHandler("status", controller.status))
    app.add_handler(CommandHandler(["tutup", "batal"], controller.close))
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND, controller.register))
    app.add_error_handler(report_error)
    return app


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    for name in ("httpx", "httpcore", "telegram", "playwright"):
        logging.getLogger(name).setLevel(logging.WARNING)
    try:
        settings = load_settings()
    except ValueError as error:
        raise SystemExit(str(error)) from None
    LOGGER.info("Bot mulai. Permintaan lama dibuang; hanya pemilik yang dapat memulai formulir.")
    if settings.owner_id is None:
        LOGGER.info("Mode penyiapan aktif. Kirim /id, isi OWNER_TELEGRAM_ID, lalu restart.")
    build_application(settings).run_polling(allowed_updates=["message"], drop_pending_updates=True)


if __name__ == "__main__":
    main()
