import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from bot import BotController, Settings, build_application
from facebook_form import FormError


class BotTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.settings = Settings("123456:FAKE_TOKEN_FOR_LOCAL_TESTS_ONLY", 42, False, Path(self.temp.name))
        self.bot = BotController(self.settings)
        self.context = SimpleNamespace(args=[])

    def tearDown(self):
        self.temp.cleanup()

    def update(self, user_id=42, chat_type="private", text="demo@example.com"):
        return SimpleNamespace(
            effective_message=SimpleNamespace(reply_text=AsyncMock(), text=text),
            effective_user=SimpleNamespace(id=user_id),
            effective_chat=SimpleNamespace(type=chat_type),
        )

    async def test_denies_other_users_without_browser_or_files(self):
        update = self.update(user_id=99)
        with patch("bot.FacebookForm") as factory:
            await self.bot.register(update, self.context)
            factory.assert_not_called()
        self.assertEqual(list(Path(self.temp.name).iterdir()), [])

    async def test_denies_group_registration(self):
        self.assertFalse(await self.bot.allowed(self.update(chat_type="group")))

    async def test_setup_mode_cannot_register(self):
        self.bot.settings = Settings(self.settings.token, None, False, Path(self.temp.name))
        update = self.update()
        with patch("bot.FacebookForm") as factory:
            await self.bot.register(update, self.context)
            factory.assert_not_called()
        self.assertIn("42", update.effective_message.reply_text.call_args.args[0])
        self.assertEqual(list(Path(self.temp.name).iterdir()), [])

    async def test_rejects_invalid_contact_before_browser(self):
        update = self.update(text="bad contact")
        with patch("bot.FacebookForm") as factory:
            await self.bot.register(update, self.context)
            factory.assert_not_called()
        self.assertEqual(list(Path(self.temp.name).iterdir()), [])

    async def test_single_active_session(self):
        self.bot.form = SimpleNamespace(is_open=True)
        with patch("bot.FacebookForm") as factory:
            await self.bot.register(self.update(), self.context)
            factory.assert_not_called()
        self.assertEqual(list(Path(self.temp.name).iterdir()), [])

    async def test_default_fills_but_does_not_submit(self):
        fake_form = SimpleNamespace(
            is_open=True, state="filled", open_and_fill=AsyncMock(),
            submit_once=AsyncMock(), close=AsyncMock(),
        )
        with patch("bot.FacebookForm", return_value=fake_form):
            await self.bot.register(self.update(), self.context)
        fake_form.open_and_fill.assert_awaited_once()
        fake_form.submit_once.assert_not_awaited()
        self.assertEqual(len(list(Path(self.temp.name).glob("session-*.json"))), 1)

    async def test_auto_submit_calls_once_and_reports_unverified(self):
        self.bot.settings = Settings(self.settings.token, 42, True, Path(self.temp.name))
        fake_form = SimpleNamespace(
            is_open=True, state="filled", open_and_fill=AsyncMock(),
            submit_once=AsyncMock(), close=AsyncMock(),
        )
        update = self.update()
        with patch("bot.FacebookForm", return_value=fake_form):
            await self.bot.register(update, self.context)
        fake_form.submit_once.assert_awaited_once()
        self.assertIn("BELUM", update.effective_message.reply_text.call_args.args[0])

    async def test_fill_error_never_submits(self):
        self.bot.settings = Settings(self.settings.token, 42, True, Path(self.temp.name))
        fake_form = SimpleNamespace(
            is_open=True, state="needs_manual", open_and_fill=AsyncMock(side_effect=FormError("Stopped")),
            submit_once=AsyncMock(), close=AsyncMock(),
        )
        with patch("bot.FacebookForm", return_value=fake_form):
            await self.bot.register(self.update(), self.context)
        fake_form.submit_once.assert_not_awaited()

    async def test_build_application_without_network(self):
        app = build_application(self.settings)
        self.assertGreater(len(app.handlers[0]), 5)
        self.assertFalse(app.running)
        self.assertNotIn(self.settings.token, repr(self.settings))


if __name__ == "__main__":
    unittest.main()
