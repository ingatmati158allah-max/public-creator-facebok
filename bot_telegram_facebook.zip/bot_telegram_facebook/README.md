# Bot Telegram → formulir Facebook

Bot Python privat yang menerima **satu nomor telepon atau satu email**, membuat profil acak, lalu mencoba mengisi formulir pendaftaran melalui Chromium. Pilihan gender dipasangkan dengan daftar nama karakter sintetis; bukan ditebak dari identitas orang nyata.

**Ini bukan bot yang menjamin akun langsung aktif.** Kode tidak membaca SMS/email, tidak menghilangkan OTP/CAPTCHA/checkpoint, dan tidak mengklaim berhasil hanya karena tombol Daftar diklik. Browser terbuka di komputer yang menjalankan Python, bukan di dalam Telegram.

> Nama dan tanggal lahir acak adalah data dummy. Untuk akun Facebook sungguhan, gunakan identitas yang sesuai ketentuan Facebook dan tanggal lahir sebenarnya. Jangan memakai tanggal palsu untuk melewati syarat usia. Otomatisasi dan identitas acak dapat memicu pembatasan atau melanggar ketentuan platform. Ketentuan: https://www.facebook.com/terms.php

## Apa yang tersedia

- Input nomor **atau** email melalui chat pribadi Telegram.
- Nama, tanggal lahir dummy, dan pilihan gender acak; password kuat dibuat otomatis.
- Opsi memakai profil sebenarnya melalui `/profil`.
- Pengisian formulir melalui browser biasa; tanpa API internal, proxy rotasi, atau layanan pemecah CAPTCHA.
- Pengiriman formulir opsional: manual dengan `/kirim`, atau sekali otomatis lewat `AUTO_SUBMIT=true`.
- Satu sesi browser aktif; hanya ID Telegram pemilik yang boleh menjalankan proses.
- Password disimpan **lokal**, tidak dikirim lewat Telegram. Tidak ada penyimpanan OTP.

## Prasyarat

- Python 3.10 atau lebih baru. Pengujian paket dilakukan dengan Python 3.11.
- Komputer Windows/macOS/Linux dengan desktop dan akses internet.
- Bot Telegram milik Anda, dibuat melalui **@BotFather**.
- Nomor/email yang Anda kuasai, serta akses untuk menerima verifikasi jika diminta.

**VPS tanpa desktop tidak cukup untuk alur manual ini.** Gunakan komputer berlayar atau desktop jarak jauh pada mesin yang menjalankan bot. Bot memakai long polling, jadi tidak membutuhkan domain, webhook, atau port publik.

## 1. Instalasi

Ekstrak ZIP, buka terminal, lalu masuk ke folder `bot_telegram_facebook`.

### Windows — PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m playwright install chromium
Copy-Item .env.example .env
```

### macOS / Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install chromium
cp .env.example .env
```

Jika Linux mengeluh tentang library sistem Chromium, pasang dependensi OS yang diperlukan. Playwright menyediakan perintah `python -m playwright install-deps chromium`; perintah ini dapat memerlukan hak administrator.

## 2. Isi token dan tentukan pemilik

1. Di Telegram, buka bot resmi **@BotFather**, jalankan `/newbot`, dan ikuti petunjuknya.
2. Buka `.env` di editor teks, lalu isi `TELEGRAM_BOT_TOKEN` dengan token Anda. **Jangan mengirim token ke percakapan ini atau memasukkannya ke Git.**
3. Untuk sementara biarkan `OWNER_TELEGRAM_ID` kosong. Jalankan bot:

   Windows:
   ```powershell
   .\.venv\Scripts\python.exe bot.py
   ```

   macOS / Linux:
   ```bash
   .venv/bin/python bot.py
   ```

4. Buka percakapan pribadi dengan bot Anda dan kirim `/id`.
5. Salin ID yang ditampilkan ke `OWNER_TELEGRAM_ID` di `.env`.
6. Hentikan bot dengan Ctrl+C, lalu jalankan lagi. Saat ID kosong, bot **tidak memproses nomor/email siapa pun**.

Bot hanya aktif selama proses Python berjalan. Jangan menjalankan dua proses polling dengan token yang sama.

## 3. Gunakan

Kirim `/start`, lalu kirim satu nomor dalam format internasional, misalnya diawali `+62` tanpa `0` domestik, atau kirim satu email. Email contoh untuk memahami format: `nama@example.com` — ini bukan alamat untuk dipakai mendaftar.

Alur default:

```text
Nomor/email Anda
    ↓
Profil acak + password dibuat
    ↓
File kredensial disimpan di komputer
    ↓
Chromium membuka dan mencoba mengisi formulir
    ↓
Anda meninjau data, lalu /kirim atau klik Daftar di browser
    ↓
Verifikasi jika diminta — selesaikan langsung di browser
```

Untuk akun sungguhan, Anda dapat mengatur data sebenarnya **sebelum** mengirim kontak:

```text
/profil Nama depan | Nama belakang | YYYY-MM-DD | perempuan/laki-laki
```

Ganti setiap bagian dengan data Anda. Versi otomatisasi ini mendukung dua pilihan gender tersebut; pilihan lain dapat ditangani manual di browser. Pengaturan `/profil` hanya berlaku selama proses bot berjalan, bukan disimpan permanen. `/acak` mengembalikan sesi berikutnya ke data dummy.

### Jika ingin langsung klik Daftar setelah mengirim nomor/email

Ubah `.env`:

```dotenv
AUTO_SUBMIT=true
```

Restart bot. Setelah formulir berhasil diisi, bot akan mengklik Daftar **satu kali**, tanpa menunggu `/kirim`. Gunakan pengaturan ini hanya setelah memahami bahwa data akan dikirim ke Facebook. Default `false` disediakan agar Anda sempat meninjau data terlebih dahulu.

**AUTO_SUBMIT tidak berarti akun terverifikasi.** Facebook masih bisa menolak formulir, meminta OTP, meminta pemeriksaan tambahan, atau membatasi otomatisasi. Jika ada timeout, bot tidak mencoba mengirim ulang karena permintaan pertama mungkin sudah diterima.

### Perintah

| Perintah | Fungsi |
|---|---|
| `/start`, `/help` | Petunjuk |
| `/id` | ID pengguna Telegram Anda |
| `/daftar <nomor atau email>` | Sama dengan mengirim kontak langsung |
| `/profil ...` | Atur profil sebenarnya untuk sesi berikutnya |
| `/acak` | Gunakan profil sintetis untuk sesi berikutnya |
| `/kirim` | Klik Daftar satu kali jika formulir siap |
| `/status` | Status tindakan bot, bukan bukti akun aktif |
| `/tutup`, `/batal` | Tutup browser; tidak membatalkan pendaftaran yang sudah dikirim |

Jangan kirim OTP ke bot. Jika diminta kode, masukkan di browser. Jika Anda sudah mengklik Daftar manual, jangan jalankan `/kirim` lagi.

## Password dan privasi

- File `credentials/session-....json` berisi kontak, profil, dan **password teks biasa**. Tidak dienkripsi. Perlakukan sebagai rahasia.
- Bot memberi tahu lokasi file, bukan isi password. Direktori dan file dibatasi ke pemilik pada sistem POSIX. Pada Windows, lindungi folder menggunakan izin akun Windows Anda.
- Simpan password ke pengelola password tepercaya, lalu hapus file lokal jika tidak diperlukan. File dibuat sebelum browser dibuka, sehingga keberadaannya **bukan bukti akun berhasil dibuat**.
- Jika Anda mengubah data atau password langsung di browser, file lokal **tidak** ikut diperbarui. Catat perubahan Anda sendiri.
- Nomor/email yang Anda kirim tetap merupakan pesan di Telegram. Chat bot bukan Secret Chat end-to-end. Jika itu tidak sesuai kebutuhan privasi Anda, jangan kirim data lewat Telegram; lakukan pendaftaran langsung di browser.
- Jangan membagikan `.env`, folder `credentials`, rekaman layar yang memuat rahasia, atau folder proyek yang sudah berisi kredensial.
- Token tidak disematkan dalam kode. Log aplikasi sengaja tidak mencetak isi error yang mungkin memuat token/password.
- Permintaan Telegram yang menumpuk saat bot offline dibuang pada startup agar tidak memicu pendaftaran tak terduga.
- `/tutup` tidak menghapus file kredensial, tidak menghapus akun, dan tidak membatalkan data yang sudah terkirim. Browser menggunakan konteks sementara; cookie tidak disimpan sebagai profil browser permanen.

## Batas dan pemecahan masalah

**Formulir berubah / checkpoint muncul:** selector berada di `facebook_form.py`. Bot akan berhenti jika tidak cocok. Periksa browser, selesaikan langkah yang sah secara manual, atau perbarui selector sesuai tampilan terbaru. Tidak ada teknik penyamaran browser atau bypass pemeriksaan.

**Browser tidak terbuka:** pastikan Chromium Playwright terpasang dan Python berjalan di lingkungan desktop. Ketik `/tutup` sebelum mencoba sesi baru setelah memperbaiki instalasi.

**Bot tidak merespons:** periksa token, koneksi, proses Python, dan apakah ada proses kedua dengan token sama. Setelah startup, kirim pesan baru; pesan lama sengaja tidak diproses.

**Tidak berhak memakai bot:** `OWNER_TELEGRAM_ID` harus sama dengan ID dari `/id`, bukan nomor telepon dan bukan username Telegram.

**Nomor ditolak:** gunakan awalan `+` dengan kode negara, bukan format lokal `08...`. Validasi format tidak menjamin nomor aktif atau diterima Facebook.

**Tidak ada SMS:** bot tidak memiliki kontrol terhadap pengiriman SMS Facebook. Jangan mengulang permintaan secara otomatis; ikuti petunjuk resmi di halaman verifikasi.

## Pengujian dan status kesiapan

**Hasil pengujian: 23 tes lokal lulus.** Lingkungan uji: Python 3.11.2, python-telegram-bot 22.8, Playwright 1.65.2, dan python-dotenv 1.2.4.

Paket ini diuji untuk logika lokal, pembatasan akses, penyimpanan kredensial, dan pengisian/klik terhadap **HTML formulir tiruan** dengan permintaan jaringan diintersep. Uji formulir tidak mengirim data ke Facebook dan tidak membuat akun.

**Belum diuji end-to-end dengan bot Telegram dan Facebook langsung.** Tidak ada token, nomor, email, atau OTP pengguna yang digunakan saat pembuatan paket ini. Struktur Facebook bisa berbeda menurut wilayah atau berubah sewaktu-waktu; kompatibilitas selector langsung tidak dijamin.

Setelah instalasi dependensi dan Chromium:

```bash
python -m unittest discover -s tests -v
```

Gunakan executable Python dari `.venv` seperti pada langkah instalasi jika terminal Anda belum mengaktifkan virtual environment.

## Isi paket

```text
bot.py                 Bot Telegram, pembatasan pemilik, perintah
facebook_form.py       Browser dan pengisian formulir
profiles.py            Profil, validasi kontak, password, file lokal
requirements.txt       Dependensi Python
.env.example           Contoh konfigurasi tanpa rahasia
.gitignore             Mengecualikan rahasia dari Git
README.md              Panduan ini
tests/                 Tes lokal dan formulir tiruan
```
