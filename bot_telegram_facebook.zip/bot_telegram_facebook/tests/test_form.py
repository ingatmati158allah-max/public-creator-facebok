"""Tes browser memakai HTML lokal yang diintersep, tanpa koneksi ke Facebook."""
import unittest
from datetime import date

from playwright.async_api import async_playwright

from facebook_form import FacebookForm, FormError, SIGNUP_URL, fill_signup_fields, is_facebook_url
from profiles import Profile


def fake_form_html():
    def options(start, end):
        return "".join(f'<option value="{n}">{n}</option>' for n in range(start, end + 1))
    return f'''<!doctype html><html><body>
    <form onsubmit="window.submitCount = (window.submitCount || 0) + 1; return false;">
      <input name="firstname"><input name="lastname">
      <input name="reg_email__"><input name="reg_email_confirmation__">
      <input name="reg_passwd__" type="password">
      <select name="birthday_day">{options(1, 31)}</select>
      <select name="birthday_month">{options(1, 12)}</select>
      <select name="birthday_year">{options(1905, 2026)}</select>
      <label><input name="sex" type="radio" value="1">Perempuan</label>
      <label><input name="sex" type="radio" value="2">Laki-laki</label>
      <button name="websubmit" type="submit">Daftar</button>
    </form></body></html>'''


class HostTests(unittest.TestCase):
    def test_facebook_host_boundary(self):
        for url in ("https://www.facebook.com/r.php", "https://m.facebook.com/", "https://facebook.com/"):
            self.assertTrue(is_facebook_url(url))
        for url in ("http://facebook.com/", "https://facebook.com.example.org/", "https://notfacebook.com/", "about:blank"):
            self.assertFalse(is_facebook_url(url))


class FormTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.playwright = await async_playwright().start()
        try:
            self.browser = await self.playwright.chromium.launch(headless=True)
        except Exception:
            await self.playwright.stop()
            raise
        self.page = await self.browser.new_page()
        self.page.set_default_timeout(1000)
        # Semua request di-fulfill dari memori: tidak ada data dikirim ke Facebook.
        await self.page.route("**/*", lambda route: route.fulfill(status=200, content_type="text/html", body=fake_form_html()))
        await self.page.goto(SIGNUP_URL)
        self.profile = Profile("Nama", "Contoh", date(1990, 6, 15), "perempuan", "TEST_PASSWORD_ONLY_42!")

    async def asyncTearDown(self):
        await self.browser.close()
        await self.playwright.stop()

    async def test_fill_email_fields_and_no_implicit_submit(self):
        await fill_signup_fields(self.page, self.profile, "demo@example.com")
        self.assertEqual(await self.page.locator('[name="firstname"]').input_value(), "Nama")
        self.assertEqual(await self.page.locator('[name="lastname"]').input_value(), "Contoh")
        self.assertEqual(await self.page.locator('[name="reg_email__"]').input_value(), "demo@example.com")
        self.assertEqual(await self.page.locator('[name="reg_email_confirmation__"]').input_value(), "demo@example.com")
        self.assertEqual(await self.page.locator('[name="reg_passwd__"]').input_value(), self.profile.password)
        self.assertEqual(await self.page.locator('[name="birthday_day"]').input_value(), "15")
        self.assertEqual(await self.page.locator('[name="birthday_month"]').input_value(), "6")
        self.assertEqual(await self.page.locator('[name="birthday_year"]').input_value(), "1990")
        self.assertTrue(await self.page.locator('[name="sex"][value="1"]').is_checked())
        self.assertEqual(await self.page.evaluate("window.submitCount || 0"), 0)

    async def test_phone_does_not_fill_email_confirmation(self):
        await fill_signup_fields(self.page, self.profile, "+12025550123")
        self.assertEqual(await self.page.locator('[name="reg_email_confirmation__"]').input_value(), "")

    async def test_submit_attempted_only_once(self):
        await fill_signup_fields(self.page, self.profile, "demo@example.com")
        form = FacebookForm(headless=True)
        form.page = self.page
        form.state = "filled"
        await form.submit_once()
        self.assertEqual(form.state, "clicked_not_verified")
        self.assertEqual(await self.page.evaluate("window.submitCount"), 1)
        with self.assertRaises(FormError):
            await form.submit_once()
        self.assertEqual(await self.page.evaluate("window.submitCount"), 1)

    async def test_wrong_domain_stops_fill(self):
        await self.page.goto("https://example.com/")
        with self.assertRaises(FormError):
            await fill_signup_fields(self.page, self.profile, "demo@example.com")
        self.assertEqual(await self.page.locator('[name="firstname"]').input_value(), "")

    async def test_unready_form_cannot_submit(self):
        form = FacebookForm(headless=True)
        form.page = self.page
        form.state = "needs_manual"
        with self.assertRaises(FormError):
            await form.submit_once()
        self.assertFalse(form.submit_attempted)
        self.assertEqual(await self.page.evaluate("window.submitCount || 0"), 0)


if __name__ == "__main__":
    unittest.main()
