import json
import os
import stat
import string
import tempfile
import unittest
from datetime import date
from pathlib import Path

from profiles import (
    DUMMY_END, DUMMY_START, NAMES, SYMBOLS, fresh_profile, make_password,
    mask_contact, normalize_contact, parse_real_profile, random_profile,
    save_credentials,
)


class ProfileTests(unittest.TestCase):
    def test_valid_contact_formats(self):
        self.assertEqual(normalize_contact(" +1 (202) 555-0123 "), "+12025550123")
        self.assertEqual(normalize_contact("Demo+test@EXAMPLE.COM"), "Demo+test@example.com")

    def test_rejects_invalid_or_multiple_contacts(self):
        for value in ("", "08123456789", "+01234567890", "+123", "not-email", "a@-example.com", "a..b@example.com", "a@example.com b@example.com", "+12025550123\n+12025550124", "x" * 255):
            with self.subTest(value=value), self.assertRaises(ValueError):
                normalize_contact(value)

    def test_masks_contacts(self):
        self.assertEqual(mask_contact("demo@example.com"), "d***@example.com")
        self.assertEqual(mask_contact("+12025550123"), "+12…0123")

    def test_synthetic_profiles_are_consistent(self):
        for _ in range(100):
            profile = random_profile()
            self.assertIn((profile.first_name, profile.last_name, profile.gender), NAMES)
            self.assertTrue(DUMMY_START <= profile.birth_date <= DUMMY_END)
            self.assertTrue(profile.synthetic)
            self.assertIn(profile.sex_value, {"1", "2"})

    def test_password_composition_and_hidden_repr(self):
        for _ in range(20):
            password = make_password()
            self.assertEqual(len(password), 20)
            for charset in (string.ascii_lowercase, string.ascii_uppercase, string.digits, SYMBOLS):
                self.assertTrue(any(c in charset for c in password))
        profile = random_profile()
        self.assertNotIn(profile.password, repr(profile))

    def test_real_profile_and_fresh_password(self):
        profile = parse_real_profile("Nama | Contoh | 1990-06-15 | perempuan")
        self.assertFalse(profile.synthetic)
        self.assertEqual(profile.birth_date, date(1990, 6, 15))
        copied = fresh_profile(profile)
        self.assertEqual(copied.full_name, profile.full_name)
        self.assertNotEqual(copied.password, profile.password)
        self.assertFalse(copied.synthetic)

    def test_invalid_profile(self):
        values = (
            "No separators",
            "Nama | Contoh | not-a-date | perempuan",
            "Nama | Contoh | 1990-02-30 | perempuan",
            "Nama | Contoh | 2999-01-01 | perempuan",
            f"Nama | Contoh | {date.today().isoformat()} | perempuan",
            " | Contoh | 1990-01-01 | perempuan",
            "Nama | Contoh | 1990-01-01 | unsupported",
        )
        for value in values:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_real_profile(value)

    def test_credentials_are_local_and_owner_only(self):
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder) / "credentials"
            profile = random_profile()
            path = save_credentials(profile, "demo@example.com", directory)
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(data["password"], profile.password)
            self.assertEqual(data["contact"], "demo@example.com")
            self.assertEqual(data["status"], "prepared_only_not_proof_of_account_creation")
            second = save_credentials(profile, "demo@example.com", directory)
            self.assertNotEqual(path, second)
            if os.name == "posix":
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
                self.assertEqual(stat.S_IMODE(directory.stat().st_mode), 0o700)


if __name__ == "__main__":
    unittest.main()
