"""Data profil, validasi kontak, dan penyimpanan kredensial lokal."""
from __future__ import annotations

import json
import os
import re
import secrets
import string
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

# Ini label untuk karakter sintetis, bukan inferensi gender orang nyata.
NAMES = (
    ("Alya", "Prameswari", "perempuan"),
    ("Dinda", "Safitri", "perempuan"),
    ("Kirana", "Lestari", "perempuan"),
    ("Nadia", "Maharani", "perempuan"),
    ("Laras", "Pertiwi", "perempuan"),
    ("Arga", "Pratama", "laki-laki"),
    ("Bima", "Saputra", "laki-laki"),
    ("Dimas", "Nugraha", "laki-laki"),
    ("Fajar", "Wijaya", "laki-laki"),
    ("Raka", "Santoso", "laki-laki"),
)
DUMMY_START = date(1985, 1, 1)
DUMMY_END = date(2000, 12, 31)
SYMBOLS = "!@#$%_-"


@dataclass(frozen=True)
class Profile:
    first_name: str
    last_name: str
    birth_date: date
    gender: str
    password: str = field(repr=False)
    synthetic: bool = True

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    @property
    def sex_value(self) -> str:
        return {"perempuan": "1", "laki-laki": "2"}[self.gender]


def make_password() -> str:
    alphabet = string.ascii_letters + string.digits + SYMBOLS
    while True:
        result = "".join(secrets.choice(alphabet) for _ in range(20))
        if all(any(char in group for char in result) for group in (
            string.ascii_lowercase, string.ascii_uppercase, string.digits, SYMBOLS
        )):
            return result


def random_profile() -> Profile:
    first, last, gender = secrets.choice(NAMES)
    birthday = DUMMY_START + timedelta(
        days=secrets.randbelow((DUMMY_END - DUMMY_START).days + 1)
    )
    return Profile(first, last, birthday, gender, make_password())


def fresh_profile(template: Profile | None) -> Profile:
    return random_profile() if template is None else replace(
        template, password=make_password()
    )


def normalize_contact(raw: str) -> str:
    value = raw.strip()
    if not value or len(value) > 254:
        raise ValueError("Masukkan satu nomor internasional atau satu alamat email.")
    if "@" in value:
        if not re.fullmatch(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,63}", value):
            raise ValueError("Format email tidak didukung. Contoh: nama@example.com")
        local, domain = value.rsplit("@", 1)
        if len(local) > 64 or local.startswith(".") or local.endswith(".") or ".." in local:
            raise ValueError("Format email tidak valid.")
        labels = domain.split(".")
        if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in labels):
            raise ValueError("Domain email tidak valid.")
        return f"{local}@{domain.lower()}"
    compact = re.sub(r"[ ()\-.]", "", value)
    if not re.fullmatch(r"\+[1-9][0-9]{7,14}", compact):
        raise ValueError(
            "Nomor harus memakai kode negara, misalnya +62 diikuti nomor tanpa 0 awal. "
            "Jangan kirim daftar nomor sekaligus."
        )
    return compact


def mask_contact(contact: str) -> str:
    if "@" in contact:
        local, domain = contact.rsplit("@", 1)
        return f"{local[:1]}***@{domain}"
    return f"{contact[:3]}…{contact[-4:]}"


def parse_real_profile(text: str) -> Profile:
    parts = [part.strip() for part in text.split("|")]
    if len(parts) != 4:
        raise ValueError(
            "Format: /profil Nama depan | Nama belakang | YYYY-MM-DD | perempuan/laki-laki"
        )
    first, last, birthday_text, gender = parts
    if any(not name or len(name) > 50 or any(ord(c) < 32 for c in name) for name in (first, last)):
        raise ValueError("Isi nama depan dan nama belakang, masing-masing maksimal 50 karakter.")
    try:
        birthday = date.fromisoformat(birthday_text)
    except ValueError:
        raise ValueError("Tanggal harus valid, dalam format YYYY-MM-DD.") from None
    today = date.today()
    age = today.year - birthday.year - ((today.month, today.day) < (birthday.month, birthday.day))
    if birthday < date(1905, 1, 1) or birthday > today:
        raise ValueError("Tanggal lahir di luar rentang yang didukung.")
    if age < 13:
        raise ValueError("Facebook mensyaratkan usia minimum; jangan gunakan tanggal palsu untuk melewatinya.")
    gender = gender.lower()
    if gender not in {"perempuan", "laki-laki"}:
        raise ValueError("Versi formulir ini mendukung pilihan perempuan atau laki-laki.")
    return Profile(first, last, birthday, gender, make_password(), synthetic=False)


def save_credentials(profile: Profile, contact: str, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name == "posix":
        directory.chmod(0o700)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = directory / f"session-{stamp}-{secrets.token_hex(4)}.json"
    record = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "prepared_only_not_proof_of_account_creation",
        "contact": contact,
        "first_name": profile.first_name,
        "last_name": profile.last_name,
        "birth_date": profile.birth_date.isoformat(),
        "gender": profile.gender,
        "synthetic_profile": profile.synthetic,
        "password": profile.password,
        "note": "Data awal. Perubahan manual di browser tidak memperbarui file ini.",
    }
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        json.dump(record, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return path
